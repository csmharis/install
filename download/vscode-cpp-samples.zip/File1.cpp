#include <iostream>
using namespace std;


int main() {
    int a, b;

    cout << "Enter two numbers: ";
    cin >> a >> b;

    cout << "Sum: " << a + b << std::endl;
    cout << "Difference: " << a - b << std::endl;
    cout << "Product: " << a * b << std::endl;
    cout << "Quotient: " << (b != 0 ? a / b : 0) << std::endl;

    return 0;
}